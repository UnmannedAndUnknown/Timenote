package edu.uwgb.debuggingclass_2;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Fade;
import android.transition.Scene;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class TimeNote extends AppCompatActivity {

    private Scene Entry;
    private Scene Memories;
    private Scene Profile;
    private Scene About;
    private Scene Dialog;

    private Scene ProfileEdit;

    private Scene adder = null;
    private Scene help = null;
    private Scene viewer = null;
    ArrayList<Notes> noteList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.background_activity);

        ViewGroup root = findViewById(R.id.rootContainer);
        Entry = Scene.getSceneForLayout(root, R.layout.activity_entrys, this);
        Memories = Scene.getSceneForLayout(root, R.layout.activity_main, this);
        Profile = Scene.getSceneForLayout(root, R.layout.activity_profile, this);
        About = Scene.getSceneForLayout(root, R.layout.activity_about, this);
        Dialog = Scene.getSceneForLayout(root, R.layout.dialog_entrys, this);
        viewer = Scene.getSceneForLayout(root, R.layout.note_viewer, this);
        ProfileEdit = Scene.getSceneForLayout(root, R.layout.profile_viewer, this);


        noteList = new ArrayList<>();
        noteList.add(new Notes("Welcome to the Internet...and My App", "10/11/2023", "Welcome Message"));

        Memories.enter();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu_xml, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item1:
                TransitionManager.go(Memories);
                break;
            case R.id.item2:
                TransitionManager.go(Entry);
                resetMainPage();
                break;
            case R.id.item3:
                TransitionManager.go(Profile);
                break;
            case R.id.item4:
                TransitionManager.go(About);
        }
        return true;
    }

    private void resetMainPage() {
        LinearLayout container = findViewById(R.id.EntryScroll);
        TextView tv = null;
        Space sp = null;

        for (int i = 0; i<noteList.size();i++) {
            Notes note = noteList.get(i);

            tv = new TextView(this);
            sp = new Space(this);

            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Transition fade = new Fade();
                    TransitionManager.go(viewer, fade);

                    TextView Entry = findViewById(R.id.viewEntry);
                    TextView Date = findViewById(R.id.viewDate);

                    Entry.setText(note.getEntry());
                    Date.setText(note.getDate());
                }
            });
            container.addView(tv);
            container.addView(sp);
            //Toast.makeText(getApplicationContext(), note.getName(), Toast.LENGTH_SHORT).show();
            tv.setText(note.getName());
            tv.setTextSize(20);

            tv.setPadding(16, 16, 16, 16);
            tv.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        }
    }

    public void MainPage(View view) {
        TransitionManager.go(Memories);
    }

    public void login(View view) {
        TransitionManager.go(Entry);
        resetMainPage();
    }

    public void profile(View view) {
        TransitionManager.go(Profile);
    }

    public void about(View view) {
        TransitionManager.go(About);
    }

    public void onClickAdd(View view) {TransitionManager.go(Dialog);}

    public void onEditProfile(View view) {TransitionManager.go(ProfileEdit);}
    public void onSaveProfile(View view) {

        TextView Name = findViewById(R.id.nameView);
        TextView Address = findViewById(R.id.addressView);
        TextView Phone = findViewById(R.id.phoneView);

        String name = Name.getText().toString();
        String address = Address.getText().toString();
        String phone = Phone.getText().toString();


        TransitionManager.go(Profile);

        TextView NameOut = findViewById(R.id.nameInput);
        TextView AddressOut = findViewById(R.id.addressInput);
        TextView PhoneOut = findViewById(R.id.phoneInput);

        NameOut.setText(name);
        AddressOut.setText(address);
        PhoneOut.setText(phone);
    }

    public void onClickSave(View view) {
        EditText notesname = findViewById(R.id.Name);
        EditText notesentry = findViewById(R.id.EntryInput);
        EditText notesdate = findViewById(R.id.DateInput);

        String notesName = notesname.getText().toString();
        String notesEntry = notesentry.getText().toString();
        String notesDate = notesdate.getText().toString();

        noteList.add(new Notes(notesEntry, notesDate, notesName));

        TransitionManager.go(Entry);
        resetMainPage();
    }
}