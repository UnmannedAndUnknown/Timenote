package edu.uwgb.debuggingclass_2;

public class Notes {
    private  String Entry;
    private  String Date;
    private  String Name;

    public Notes (){

    }
    public Notes (String entry, String date, String name){
        Entry = entry;
        Date = date;
        Name= name;
    }
    public  String getEntry(){return Entry;}
    public  String getDate(){return Date;}

    public  String getName(){return Name;}


    public void setDate(String date){Date =date;}

    public void setEntry(String entry){Entry=entry;}

    public void setName(String name){Name=name;}

}
